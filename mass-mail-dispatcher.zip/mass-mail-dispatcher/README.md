# Bulk_Mail_Dispatcher-
This is web development project to send bulk mail.

This is a website to send bulk mail using CSV file.

This is developed in python using flask, smtplib, csv, re and pandas library.
